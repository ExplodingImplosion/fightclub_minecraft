import random


directory = "C:/Users/disto/OneDrive/Documents/MultiMC/instances/Fabulously Optimized 5.4.0-alpha.4/.minecraft/saves/project fw/datapacks/Colourful Calibers - Datapack/data/raycast/functions/spread/"

filename = "15.mcfunction"
full_directory = directory+filename
spread = open(full_directory,'w')

x = [-0.3,0.3]
y = [-0.2,0.2]

data = "execute store result score @s fwg.rng run random value 1..12\n"
spread.write(data)
for i in range(1,13):
    data = "execute if score @s fwg.rng matches "+str(i)+" as @s anchored eyes rotated ~"+str(round(random.uniform(x[0], x[1]), 2))+" ~"+str(round(random.uniform(y[0],y[1]), 2))+" run function raycast:bullets/start\n"
    spread.write(data)
spread.close()
